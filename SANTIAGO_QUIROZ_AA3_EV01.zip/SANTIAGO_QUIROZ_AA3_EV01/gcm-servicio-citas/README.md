# GCM - Servicio de Citas (Spring Boot)

Evidencia **GA7-220501096-AA3-EV01** - Codificación de módulos del software stand-alone, web y móvil.
Aprendiz: Santiago Quiroz Galvis - SENA, Tecnología en Análisis y Desarrollo de Software (ficha 3336049).

Módulo de gestión de citas del **Gestor de Citas Médicas (GCM)** construido con el framework **Spring Boot 3** (Java 17), Spring Data JPA y una API REST. Es la evolución de los módulos de las evidencias AA2-EV01 (JDBC) y AA2-EV02 (Servlets y JSP): se mantiene la misma tabla `citas` de `gcm_bd` y las mismas reglas de negocio, pero el framework reemplaza el código manual de conexión, consultas y controladores.

## Cómo se relaciona con el diseño del GCM

El GCM se diseñó con una arquitectura de servicios sobre Spring Boot y JPA/Hibernate. Este proyecto implementa el **servicio de citas**: es dueño de la tabla `citas` y guarda al paciente y al profesional solo por su identificador, sin depender de las entidades de otros servicios. Casos de uso que cubre: agendar una cita, consultar citas (todas, por paciente o por estado), modificar o reprogramar una cita, cancelarla y eliminarla.

Patrones aplicados: Singleton (los componentes de Spring se crean una sola vez), Fachada (`CitaServicio` es la única puerta de entrada a la lógica del módulo), Repositorio (`CitaRepositorio`) y DTO (`CitaSolicitud` y `CitaRespuesta`).

## Estructura

```
gcm-servicio-citas/
├── pom.xml                              Dependencias (Spring Boot, JPA, validación, H2, MySQL, PostgreSQL)
├── sql/gcm_modulo_citas.sql             Script de gcm_bd para el perfil mysql
├── docs/pruebas.http                    Peticiones de ejemplo para probar la API
└── src
    ├── main/java/co/edu/sena/gcm/
    │   ├── GcmServicioCitasApplication  Punto de entrada
    │   ├── controlador/CitaControlador  Endpoints REST (/api/citas)
    │   ├── servicio/CitaServicio        Reglas de negocio
    │   ├── repositorio/CitaRepositorio  Acceso a datos (Spring Data JPA)
    │   ├── modelo/Cita, EstadoCita      Entidad JPA y enumeración
    │   ├── dto/CitaSolicitud, CitaRespuesta   Datos de entrada y salida de la API
    │   └── excepcion/                   Excepciones propias y ManejadorGlobalExcepciones
    ├── main/resources/                  application.properties (+ perfiles mysql y postgres), data.sql
    └── test/java/                       Pruebas unitarias (Mockito) y de integración (MockMvc)
```

## API REST

| Operación CRUD | Método y ruta | Respuesta |
|---|---|---|
| Inserción | `POST /api/citas` | 201 con la cita creada y cabecera `Location` |
| Consulta | `GET /api/citas` (filtros opcionales `idPaciente` y `estado`) | 200 con la lista |
| Consulta | `GET /api/citas/{idCita}` | 200, o 404 si no existe |
| Actualización | `PUT /api/citas/{idCita}` | 200 con la cita actualizada |
| Actualización de estado | `PATCH /api/citas/{idCita}/cancelar` | 200 con estado CANCELADA |
| Eliminación | `DELETE /api/citas/{idCita}` | 204 sin cuerpo |

Reglas de negocio (en `CitaServicio`): una cita nueva o reprogramada debe tener fecha futura (422 si no); un profesional no puede tener dos citas PROGRAMADA o CONFIRMADA a la misma hora (409); una cita ATENDIDA no se puede modificar ni cancelar (422); al registrar, la cita siempre inicia PROGRAMADA. Los datos inválidos (campos vacíos, identificadores negativos, JSON mal formado, estado inexistente) responden 400 con el detalle por campo. Todas las respuestas de error usan el formato estándar ProblemDetail de Spring.

## Estándares de codificación

| Elemento | Convención | Ejemplos |
|---|---|---|
| Paquetes | minúsculas, dominio invertido | `co.edu.sena.gcm.servicio` |
| Clases e interfaces | PascalCase, sustantivos; sufijo según su rol | `CitaServicio`, `CitaRepositorio`, `CitaControlador` |
| Métodos | camelCase, empiezan con verbo | `registrarCita`, `validarDisponibilidad` |
| Variables y atributos | camelCase, nombres descriptivos | `idProfesional`, `fechaHora` |
| Constantes | MAYÚSCULAS con guion bajo | `ESTADOS_ACTIVOS` |
| Tablas y columnas | minúsculas con guion bajo | `citas`, `id_profesional` |

Todas las clases y métodos públicos tienen comentarios Javadoc, y las reglas con lógica menos evidente tienen comentarios en línea.

## Ejecución

Requisitos: JDK 17 o superior y Maven 3.9 o superior (o un IDE con soporte Maven, como NetBeans, IntelliJ o VS Code).

1. **Sin instalar base de datos (perfil por defecto, H2 en memoria):** desde esta carpeta ejecute `mvn spring-boot:run`. La aplicación queda en `http://localhost:8080` con tres citas de ejemplo.
2. **Con MySQL (`gcm_bd`):** ejecute `sql/gcm_modulo_citas.sql`, defina las variables de entorno `GCM_BD_USUARIO` y `GCM_BD_CLAVE` y ejecute `mvn spring-boot:run -Dspring-boot.run.profiles=mysql`. Como la tabla `citas` tiene llaves foráneas, use solo los pacientes y profesionales 1 y 2 que crea el script.
3. **Con PostgreSQL:** cree una base vacía `gcm_bd` y ejecute `mvn spring-boot:run -Dspring-boot.run.profiles=postgres`; Hibernate crea la tabla.

Para probar los endpoints abra `docs/pruebas.http` en VS Code (extensión REST Client) o IntelliJ, o use Postman con las rutas de la tabla anterior.

## Pruebas

`mvn test` ejecuta 6 pruebas unitarias de las reglas de negocio (`CitaServicioTest`, con Mockito) y 6 pruebas de integración de la API (`CitaControladorIntegracionTest`, con MockMvc y H2).

## Control de versiones

El proyecto se gestiona con Git; el historial de commits muestra la construcción por capas (configuración, modelo, repositorio, servicio, controlador, manejo de errores, pruebas y documentación). El enlace del repositorio remoto está en `ENLACE_REPOSITORIO.txt`.
