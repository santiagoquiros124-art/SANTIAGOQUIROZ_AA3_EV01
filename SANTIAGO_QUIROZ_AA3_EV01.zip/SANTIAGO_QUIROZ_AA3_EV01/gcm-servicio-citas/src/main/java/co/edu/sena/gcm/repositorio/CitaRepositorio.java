package co.edu.sena.gcm.repositorio;

import co.edu.sena.gcm.modelo.Cita;
import co.edu.sena.gcm.modelo.EstadoCita;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repositorio de acceso a datos de la tabla citas.
 *
 * <p>Spring Data JPA genera la implementacion en tiempo de ejecucion. Hereda de
 * {@link JpaRepository} las operaciones basicas (save, findById, findAll, deleteById, ...)
 * y las consultas adicionales se declaran con el nombre del metodo: Spring lo traduce a SQL.</p>
 *
 * @author Santiago Quiroz Galvis
 */
public interface CitaRepositorio extends JpaRepository<Cita, Long> {

    /** Citas de un paciente ordenadas de la mas cercana a la mas lejana. */
    List<Cita> findByIdPacienteOrderByFechaHora(Long idPaciente);

    /** Citas en un estado dado, ordenadas por fecha. */
    List<Cita> findByEstadoOrderByFechaHora(EstadoCita estado);

    /** Indica si el profesional ya tiene una cita en ese momento con alguno de los estados dados. */
    boolean existsByIdProfesionalAndFechaHoraAndEstadoIn(Long idProfesional,
            LocalDateTime fechaHora, Collection<EstadoCita> estados);

    /** Igual que la anterior pero ignorando una cita (la que se esta editando). */
    boolean existsByIdProfesionalAndFechaHoraAndEstadoInAndIdCitaNot(Long idProfesional,
            LocalDateTime fechaHora, Collection<EstadoCita> estados, Long idCitaExcluida);
}
