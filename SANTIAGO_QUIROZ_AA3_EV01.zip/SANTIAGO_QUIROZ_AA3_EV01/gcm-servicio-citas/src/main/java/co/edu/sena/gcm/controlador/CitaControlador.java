package co.edu.sena.gcm.controlador;

import co.edu.sena.gcm.dto.CitaRespuesta;
import co.edu.sena.gcm.dto.CitaSolicitud;
import co.edu.sena.gcm.modelo.Cita;
import co.edu.sena.gcm.modelo.EstadoCita;
import co.edu.sena.gcm.servicio.CitaServicio;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

/**
 * API REST del modulo de citas. Cada metodo corresponde a una operacion del CRUD:
 *
 * <pre>
 *   POST   /api/citas                    registrar una cita          (insercion)
 *   GET    /api/citas                    listar, con filtros         (consulta)
 *   GET    /api/citas/{idCita}           consultar una cita          (consulta)
 *   PUT    /api/citas/{idCita}           actualizar una cita         (actualizacion)
 *   PATCH  /api/citas/{idCita}/cancelar  cancelar una cita           (actualizacion de estado)
 *   DELETE /api/citas/{idCita}           eliminar una cita           (eliminacion)
 * </pre>
 *
 * <p>El controlador no contiene reglas de negocio: valida el formato de los datos,
 * delega en {@link CitaServicio} y traduce el resultado a una respuesta HTTP.</p>
 *
 * @author Santiago Quiroz Galvis
 */
@RestController
@RequestMapping("/api/citas")
public class CitaControlador {

    private final CitaServicio citaServicio;

    public CitaControlador(CitaServicio citaServicio) {
        this.citaServicio = citaServicio;
    }

    /** Registra una cita y responde 201 con la cabecera Location apuntando a la nueva cita. */
    @PostMapping
    public ResponseEntity<CitaRespuesta> registrarCita(@Valid @RequestBody CitaSolicitud solicitud) {
        Cita citaCreada = citaServicio.registrar(solicitud);
        URI ubicacion = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{idCita}")
                .buildAndExpand(citaCreada.getIdCita())
                .toUri();
        return ResponseEntity.created(ubicacion).body(CitaRespuesta.desde(citaCreada));
    }

    /** Lista las citas; los parametros idPaciente y estado son opcionales. */
    @GetMapping
    public List<CitaRespuesta> listarCitas(
            @RequestParam(name = "idPaciente", required = false) Long idPaciente,
            @RequestParam(name = "estado", required = false) EstadoCita estado) {
        return citaServicio.listar(idPaciente, estado).stream()
                .map(CitaRespuesta::desde)
                .toList();
    }

    /** Devuelve una cita por su identificador (404 si no existe). */
    @GetMapping("/{idCita}")
    public CitaRespuesta consultarCita(@PathVariable("idCita") Long idCita) {
        return CitaRespuesta.desde(citaServicio.obtener(idCita));
    }

    /** Reemplaza los datos de una cita existente. */
    @PutMapping("/{idCita}")
    public CitaRespuesta actualizarCita(@PathVariable("idCita") Long idCita,
            @Valid @RequestBody CitaSolicitud solicitud) {
        return CitaRespuesta.desde(citaServicio.actualizar(idCita, solicitud));
    }

    /** Cancela una cita (cambia su estado a CANCELADA). */
    @PatchMapping("/{idCita}/cancelar")
    public CitaRespuesta cancelarCita(@PathVariable("idCita") Long idCita) {
        return CitaRespuesta.desde(citaServicio.cancelar(idCita));
    }

    /** Elimina una cita y responde 204 sin cuerpo. */
    @DeleteMapping("/{idCita}")
    public ResponseEntity<Void> eliminarCita(@PathVariable("idCita") Long idCita) {
        citaServicio.eliminar(idCita);
        return ResponseEntity.noContent().build();
    }
}
