package co.edu.sena.gcm.excepcion;

import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

/**
 * Traduce las excepciones del modulo a respuestas HTTP con un cuerpo JSON uniforme
 * (formato estandar ProblemDetail de Spring: status, title y detail).
 *
 * <p>Asi los controladores no necesitan bloques try/catch: lanzan la excepcion y este
 * manejador decide el codigo de estado.</p>
 *
 * @author Santiago Quiroz Galvis
 */
@RestControllerAdvice
public class ManejadorGlobalExcepciones {

    /** 404: la cita buscada no existe. */
    @ExceptionHandler(RecursoNoEncontradoException.class)
    public ProblemDetail manejarRecursoNoEncontrado(RecursoNoEncontradoException excepcion) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, excepcion.getMessage());
    }

    /** 409: el profesional ya tiene una cita en ese horario. */
    @ExceptionHandler(ConflictoHorarioException.class)
    public ProblemDetail manejarConflictoHorario(ConflictoHorarioException excepcion) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT, excepcion.getMessage());
    }

    /** 422: la peticion esta bien escrita pero incumple una regla del negocio. */
    @ExceptionHandler(ReglaNegocioException.class)
    public ProblemDetail manejarReglaNegocio(ReglaNegocioException excepcion) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.UNPROCESSABLE_ENTITY, excepcion.getMessage());
    }

    /** 400: fallaron las validaciones del DTO; se informa el mensaje de cada campo. */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ProblemDetail manejarValidacion(MethodArgumentNotValidException excepcion) {
        Map<String, String> erroresPorCampo = new LinkedHashMap<>();
        excepcion.getBindingResult().getFieldErrors()
                .forEach(error -> erroresPorCampo.put(error.getField(), error.getDefaultMessage()));

        ProblemDetail problema = ProblemDetail.forStatusAndDetail(
                HttpStatus.BAD_REQUEST, "Los datos enviados no son validos");
        problema.setProperty("errores", erroresPorCampo);
        return problema;
    }

    /** 400: el JSON esta mal formado o trae un valor no permitido (fecha o estado invalidos). */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ProblemDetail manejarCuerpoIlegible(HttpMessageNotReadableException excepcion) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST,
                "El cuerpo de la peticion no es un JSON valido o contiene valores no permitidos "
                + "(por ejemplo, un estado inexistente o una fecha con formato incorrecto)");
    }

    /** 400: un parametro de la URL tiene un tipo incorrecto (por ejemplo, estado=XYZ). */
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ProblemDetail manejarTipoIncorrecto(MethodArgumentTypeMismatchException excepcion) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST,
                "El valor del parametro '" + excepcion.getName() + "' no es valido");
    }
}
