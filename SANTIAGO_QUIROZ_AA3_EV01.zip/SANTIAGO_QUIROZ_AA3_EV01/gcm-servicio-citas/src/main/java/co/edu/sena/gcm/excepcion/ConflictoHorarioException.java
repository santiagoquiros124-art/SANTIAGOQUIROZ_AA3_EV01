package co.edu.sena.gcm.excepcion;

/**
 * Se lanza cuando el profesional ya tiene una cita activa en la fecha y hora solicitadas.
 * La API la responde con HTTP 409 (conflicto).
 *
 * @author Santiago Quiroz Galvis
 */
public class ConflictoHorarioException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ConflictoHorarioException(String mensaje) {
        super(mensaje);
    }
}
