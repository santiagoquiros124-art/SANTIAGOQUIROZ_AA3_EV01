package co.edu.sena.gcm.excepcion;

/**
 * Se lanza cuando se busca una cita que no existe. La API la responde con HTTP 404.
 *
 * @author Santiago Quiroz Galvis
 */
public class RecursoNoEncontradoException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public RecursoNoEncontradoException(String mensaje) {
        super(mensaje);
    }
}
