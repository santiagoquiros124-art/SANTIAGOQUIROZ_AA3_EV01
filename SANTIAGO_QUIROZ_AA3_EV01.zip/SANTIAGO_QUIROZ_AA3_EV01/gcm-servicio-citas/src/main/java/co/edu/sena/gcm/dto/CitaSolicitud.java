package co.edu.sena.gcm.dto;

import co.edu.sena.gcm.modelo.EstadoCita;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

/**
 * Datos que el cliente envia en formato JSON para registrar o actualizar una cita.
 *
 * <p>Es un DTO (objeto de transferencia de datos): separa lo que expone la API de la
 * entidad de base de datos. Las anotaciones de validacion se comprueban cuando el
 * controlador recibe el objeto con {@code @Valid}.</p>
 *
 * @param idPaciente     identificador del paciente que solicita la cita
 * @param idProfesional  identificador del profesional que la atendera
 * @param fechaHora      fecha y hora en formato ISO, por ejemplo 2026-12-05T09:30:00
 * @param motivoConsulta razon de la consulta (maximo 255 caracteres)
 * @param estado         opcional; al registrar se ignora y la cita inicia PROGRAMADA
 * @author Santiago Quiroz Galvis
 */
public record CitaSolicitud(
        @NotNull(message = "El identificador del paciente es obligatorio")
        @Positive(message = "El identificador del paciente debe ser mayor que cero")
        Long idPaciente,

        @NotNull(message = "El identificador del profesional es obligatorio")
        @Positive(message = "El identificador del profesional debe ser mayor que cero")
        Long idProfesional,

        @NotNull(message = "La fecha y hora de la cita son obligatorias")
        LocalDateTime fechaHora,

        @NotBlank(message = "El motivo de consulta es obligatorio")
        @Size(max = 255, message = "El motivo de consulta no puede superar 255 caracteres")
        String motivoConsulta,

        EstadoCita estado) {
}
