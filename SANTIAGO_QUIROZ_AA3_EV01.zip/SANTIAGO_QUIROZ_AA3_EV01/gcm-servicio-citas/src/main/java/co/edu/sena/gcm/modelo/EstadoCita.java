package co.edu.sena.gcm.modelo;

/**
 * Estados por los que pasa una cita medica en el GCM.
 *
 * <ul>
 *   <li>PROGRAMADA: la cita fue agendada y espera confirmacion.</li>
 *   <li>CONFIRMADA: el paciente confirmo su asistencia.</li>
 *   <li>CANCELADA: la cita no se realizara y su horario queda libre.</li>
 *   <li>ATENDIDA: la consulta ya se realizo; la cita no se puede modificar.</li>
 * </ul>
 *
 * @author Santiago Quiroz Galvis
 */
public enum EstadoCita {
    PROGRAMADA,
    CONFIRMADA,
    CANCELADA,
    ATENDIDA
}
