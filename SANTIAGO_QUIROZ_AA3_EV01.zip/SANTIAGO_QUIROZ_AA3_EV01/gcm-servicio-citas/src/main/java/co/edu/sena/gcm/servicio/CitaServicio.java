package co.edu.sena.gcm.servicio;

import co.edu.sena.gcm.dto.CitaSolicitud;
import co.edu.sena.gcm.excepcion.ConflictoHorarioException;
import co.edu.sena.gcm.excepcion.RecursoNoEncontradoException;
import co.edu.sena.gcm.excepcion.ReglaNegocioException;
import co.edu.sena.gcm.modelo.Cita;
import co.edu.sena.gcm.modelo.EstadoCita;
import co.edu.sena.gcm.repositorio.CitaRepositorio;
import java.time.LocalDateTime;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Logica de negocio del modulo de citas. Actua como fachada del modulo: el controlador
 * solo habla con esta clase y esta se encarga de aplicar las reglas y usar el repositorio.
 *
 * <p>Reglas implementadas:</p>
 * <ul>
 *   <li>Una cita nueva (o reprogramada) debe tener fecha futura.</li>
 *   <li>Un profesional no puede tener dos citas activas (PROGRAMADA o CONFIRMADA) a la misma hora.</li>
 *   <li>Una cita ATENDIDA no se puede modificar ni cancelar.</li>
 * </ul>
 *
 * @author Santiago Quiroz Galvis
 */
@Service
public class CitaServicio {

    /** Estados en los que una cita ocupa el horario del profesional. */
    private static final Set<EstadoCita> ESTADOS_ACTIVOS =
            EnumSet.of(EstadoCita.PROGRAMADA, EstadoCita.CONFIRMADA);

    private final CitaRepositorio citaRepositorio;

    /** Inyeccion por constructor: Spring entrega el repositorio al crear el servicio. */
    public CitaServicio(CitaRepositorio citaRepositorio) {
        this.citaRepositorio = citaRepositorio;
    }

    /**
     * Registra una cita nueva. Siempre inicia en estado PROGRAMADA, sin importar el
     * estado que venga en la solicitud.
     */
    @Transactional
    public Cita registrar(CitaSolicitud solicitud) {
        validarFechaFutura(solicitud.fechaHora());
        validarDisponibilidad(solicitud.idProfesional(), solicitud.fechaHora(), null);

        Cita cita = new Cita();
        cita.setIdPaciente(solicitud.idPaciente());
        cita.setIdProfesional(solicitud.idProfesional());
        cita.setFechaHora(solicitud.fechaHora());
        cita.setMotivoConsulta(solicitud.motivoConsulta().trim());
        cita.setEstado(EstadoCita.PROGRAMADA);
        return citaRepositorio.save(cita);
    }

    /**
     * Consulta las citas con filtros opcionales. Sin filtros devuelve todas, ordenadas por fecha.
     *
     * @param idPaciente si no es nulo, solo las citas de ese paciente
     * @param estado     si no es nulo, solo las citas en ese estado
     */
    @Transactional(readOnly = true)
    public List<Cita> listar(Long idPaciente, EstadoCita estado) {
        if (idPaciente != null) {
            List<Cita> citasDelPaciente = citaRepositorio.findByIdPacienteOrderByFechaHora(idPaciente);
            if (estado == null) {
                return citasDelPaciente;
            }
            return citasDelPaciente.stream()
                    .filter(cita -> cita.getEstado() == estado)
                    .toList();
        }
        if (estado != null) {
            return citaRepositorio.findByEstadoOrderByFechaHora(estado);
        }
        return citaRepositorio.findAll(Sort.by("fechaHora"));
    }

    /** Busca una cita por su identificador o lanza {@link RecursoNoEncontradoException}. */
    @Transactional(readOnly = true)
    public Cita obtener(Long idCita) {
        return citaRepositorio.findById(idCita)
                .orElseThrow(() -> new RecursoNoEncontradoException(
                        "No existe una cita con identificador " + idCita));
    }

    /**
     * Actualiza los datos de una cita existente. Si la solicitud trae un estado, la cita
     * pasa a ese estado; si no, conserva el que tenia.
     */
    @Transactional
    public Cita actualizar(Long idCita, CitaSolicitud solicitud) {
        Cita cita = obtener(idCita);
        if (cita.getEstado() == EstadoCita.ATENDIDA) {
            throw new ReglaNegocioException("Una cita atendida no se puede modificar");
        }

        // Solo se exige fecha futura si realmente se esta cambiando la fecha
        if (!solicitud.fechaHora().equals(cita.getFechaHora())) {
            validarFechaFutura(solicitud.fechaHora());
        }

        EstadoCita estadoFinal = solicitud.estado() != null ? solicitud.estado() : cita.getEstado();
        if (ESTADOS_ACTIVOS.contains(estadoFinal)) {
            // Se excluye la propia cita para que no choque consigo misma
            validarDisponibilidad(solicitud.idProfesional(), solicitud.fechaHora(), idCita);
        }

        cita.setIdPaciente(solicitud.idPaciente());
        cita.setIdProfesional(solicitud.idProfesional());
        cita.setFechaHora(solicitud.fechaHora());
        cita.setMotivoConsulta(solicitud.motivoConsulta().trim());
        cita.setEstado(estadoFinal);
        return citaRepositorio.save(cita);
    }

    /** Cambia el estado de la cita a CANCELADA, lo que libera el horario del profesional. */
    @Transactional
    public Cita cancelar(Long idCita) {
        Cita cita = obtener(idCita);
        if (cita.getEstado() == EstadoCita.ATENDIDA) {
            throw new ReglaNegocioException("Una cita atendida no se puede cancelar");
        }
        cita.setEstado(EstadoCita.CANCELADA);
        return citaRepositorio.save(cita);
    }

    /** Elimina definitivamente la cita de la base de datos. */
    @Transactional
    public void eliminar(Long idCita) {
        if (!citaRepositorio.existsById(idCita)) {
            throw new RecursoNoEncontradoException("No existe una cita con identificador " + idCita);
        }
        citaRepositorio.deleteById(idCita);
    }

    // ------------------------------------------------------------ reglas privadas

    private void validarFechaFutura(LocalDateTime fechaHora) {
        if (!fechaHora.isAfter(LocalDateTime.now())) {
            throw new ReglaNegocioException("La fecha y hora de la cita deben ser futuras");
        }
    }

    /**
     * Verifica que el profesional este libre en esa fecha y hora.
     *
     * @param idCitaExcluida identificador de la cita que se esta editando, o nulo al registrar
     */
    private void validarDisponibilidad(Long idProfesional, LocalDateTime fechaHora, Long idCitaExcluida) {
        boolean horarioOcupado = idCitaExcluida == null
                ? citaRepositorio.existsByIdProfesionalAndFechaHoraAndEstadoIn(
                        idProfesional, fechaHora, ESTADOS_ACTIVOS)
                : citaRepositorio.existsByIdProfesionalAndFechaHoraAndEstadoInAndIdCitaNot(
                        idProfesional, fechaHora, ESTADOS_ACTIVOS, idCitaExcluida);
        if (horarioOcupado) {
            throw new ConflictoHorarioException(
                    "El profesional " + idProfesional + " ya tiene una cita activa en ese horario");
        }
    }
}
