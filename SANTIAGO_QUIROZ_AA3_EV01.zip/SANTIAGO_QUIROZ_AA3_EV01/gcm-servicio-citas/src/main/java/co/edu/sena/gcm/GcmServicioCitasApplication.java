package co.edu.sena.gcm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Punto de entrada del servicio de citas del Gestor de Citas Medicas (GCM).
 *
 * <p>La anotacion {@code @SpringBootApplication} activa la configuracion automatica,
 * el escaneo de componentes de este paquete y sus subpaquetes, y levanta el servidor
 * Tomcat embebido.</p>
 *
 * @author Santiago Quiroz Galvis
 */
@SpringBootApplication
public class GcmServicioCitasApplication {

    public static void main(String[] argumentos) {
        SpringApplication.run(GcmServicioCitasApplication.class, argumentos);
    }
}
