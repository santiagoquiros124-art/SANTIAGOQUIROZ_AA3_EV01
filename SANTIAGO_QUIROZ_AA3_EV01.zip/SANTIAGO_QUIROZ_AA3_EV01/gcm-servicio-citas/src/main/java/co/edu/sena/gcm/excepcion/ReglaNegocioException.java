package co.edu.sena.gcm.excepcion;

/**
 * Se lanza cuando una peticion es valida en su formato pero incumple una regla del
 * negocio (por ejemplo, agendar en una fecha pasada). La API la responde con HTTP 422.
 *
 * @author Santiago Quiroz Galvis
 */
public class ReglaNegocioException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ReglaNegocioException(String mensaje) {
        super(mensaje);
    }
}
