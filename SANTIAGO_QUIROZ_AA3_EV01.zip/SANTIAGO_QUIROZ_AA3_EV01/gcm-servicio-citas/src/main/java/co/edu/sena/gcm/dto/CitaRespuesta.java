package co.edu.sena.gcm.dto;

import co.edu.sena.gcm.modelo.Cita;
import co.edu.sena.gcm.modelo.EstadoCita;
import java.time.LocalDateTime;

/**
 * Datos de una cita tal como los devuelve la API en formato JSON.
 *
 * @param idCita         identificador de la cita
 * @param idPaciente     identificador del paciente
 * @param idProfesional  identificador del profesional
 * @param fechaHora      fecha y hora de la cita
 * @param motivoConsulta razon de la consulta
 * @param estado         estado actual de la cita
 * @author Santiago Quiroz Galvis
 */
public record CitaRespuesta(
        Long idCita,
        Long idPaciente,
        Long idProfesional,
        LocalDateTime fechaHora,
        String motivoConsulta,
        EstadoCita estado) {

    /** Metodo de fabrica estatico: convierte una entidad Cita en su representacion de respuesta. */
    public static CitaRespuesta desde(Cita cita) {
        return new CitaRespuesta(
                cita.getIdCita(),
                cita.getIdPaciente(),
                cita.getIdProfesional(),
                cita.getFechaHora(),
                cita.getMotivoConsulta(),
                cita.getEstado());
    }
}
