-- Datos de ejemplo para la base H2 en memoria (solo se cargan con el perfil por defecto)
INSERT INTO citas (id_paciente, id_profesional, fecha_hora, motivo_consulta, estado) VALUES
    (1, 1, '2026-12-01 09:00:00', 'Control general', 'PROGRAMADA'),
    (2, 1, '2026-12-01 10:00:00', 'Dolor de cabeza frecuente', 'CONFIRMADA'),
    (1, 2, '2026-12-02 14:30:00', 'Revision de resultados de laboratorio', 'PROGRAMADA');
