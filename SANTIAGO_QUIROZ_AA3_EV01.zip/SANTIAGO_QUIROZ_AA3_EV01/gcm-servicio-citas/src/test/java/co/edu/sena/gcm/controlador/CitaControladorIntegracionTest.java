package co.edu.sena.gcm.controlador;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.jayway.jsonpath.JsonPath;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

/**
 * Pruebas de integracion de la API REST: levantan el contexto completo de Spring con la
 * base H2 en memoria y envian peticiones HTTP simuladas con MockMvc.
 *
 * <p>Cada prueba usa identificadores de profesional distintos para no chocar entre si,
 * porque todas comparten la misma base de datos en memoria.</p>
 *
 * @author Santiago Quiroz Galvis
 */
@SpringBootTest
@AutoConfigureMockMvc
class CitaControladorIntegracionTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void cicloCompletoRegistrarConsultarActualizarCancelarYEliminar() throws Exception {
        LocalDateTime fecha = LocalDateTime.now().plusDays(20).truncatedTo(ChronoUnit.MINUTES);

        // Insercion: POST responde 201, con cabecera Location y estado PROGRAMADA
        MvcResult resultado = mockMvc.perform(post("/api/citas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(crearJson(10, 70, fecha, "Control general")))
                .andExpect(status().isCreated())
                .andExpect(header().exists("Location"))
                .andExpect(jsonPath("$.estado").value("PROGRAMADA"))
                .andReturn();
        Number identificador = JsonPath.read(resultado.getResponse().getContentAsString(), "$.idCita");
        long idCita = identificador.longValue();

        // Consulta por identificador
        mockMvc.perform(get("/api/citas/" + idCita))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.motivoConsulta").value("Control general"));

        // Actualizacion
        mockMvc.perform(put("/api/citas/" + idCita)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(crearJson(10, 70, fecha, "Motivo actualizado")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.motivoConsulta").value("Motivo actualizado"));

        // Cancelacion (cambio de estado)
        mockMvc.perform(patch("/api/citas/" + idCita + "/cancelar"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("CANCELADA"));

        // Eliminacion: 204 y luego la cita ya no existe (404)
        mockMvc.perform(delete("/api/citas/" + idCita))
                .andExpect(status().isNoContent());
        mockMvc.perform(get("/api/citas/" + idCita))
                .andExpect(status().isNotFound());
    }

    @Test
    void registrarCitaEnHorarioOcupadoResponde409() throws Exception {
        LocalDateTime fecha = LocalDateTime.now().plusDays(21).truncatedTo(ChronoUnit.MINUTES);

        mockMvc.perform(post("/api/citas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(crearJson(10, 71, fecha, "Primera cita")))
                .andExpect(status().isCreated());

        // Mismo profesional, misma fecha y hora, otro paciente
        mockMvc.perform(post("/api/citas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(crearJson(11, 71, fecha, "Segunda cita")))
                .andExpect(status().isConflict());
    }

    @Test
    void registrarCitaConFechaPasadaResponde422() throws Exception {
        LocalDateTime fechaPasada = LocalDateTime.now().minusDays(2).truncatedTo(ChronoUnit.MINUTES);

        mockMvc.perform(post("/api/citas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(crearJson(10, 72, fechaPasada, "Fecha pasada")))
                .andExpect(status().isUnprocessableEntity());
    }

    @Test
    void registrarCitaConDatosInvalidosResponde400ConErroresPorCampo() throws Exception {
        String cuerpoInvalido = "{\"idPaciente\": -1, \"motivoConsulta\": \"\"}";

        mockMvc.perform(post("/api/citas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(cuerpoInvalido))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errores").exists());
    }

    @Test
    void listarCitasFiltraPorPacienteConLosDatosDeEjemplo() throws Exception {
        // data.sql registra exactamente dos citas del paciente 1
        mockMvc.perform(get("/api/citas").param("idPaciente", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2));
    }

    @Test
    void listarCitasConEstadoInexistenteResponde400() throws Exception {
        mockMvc.perform(get("/api/citas").param("estado", "XYZ"))
                .andExpect(status().isBadRequest());
    }

    /** Arma el cuerpo JSON de una solicitud de cita. */
    private String crearJson(long idPaciente, long idProfesional, LocalDateTime fechaHora, String motivo) {
        return """
                {"idPaciente": %d, "idProfesional": %d, "fechaHora": "%s", "motivoConsulta": "%s"}
                """.formatted(idPaciente, idProfesional, fechaHora, motivo);
    }
}
