package co.edu.sena.gcm.servicio;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.edu.sena.gcm.dto.CitaSolicitud;
import co.edu.sena.gcm.excepcion.ConflictoHorarioException;
import co.edu.sena.gcm.excepcion.RecursoNoEncontradoException;
import co.edu.sena.gcm.excepcion.ReglaNegocioException;
import co.edu.sena.gcm.modelo.Cita;
import co.edu.sena.gcm.modelo.EstadoCita;
import co.edu.sena.gcm.repositorio.CitaRepositorio;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Pruebas unitarias de las reglas de negocio de {@link CitaServicio}.
 * El repositorio se simula con Mockito, por lo que no se necesita base de datos.
 *
 * @author Santiago Quiroz Galvis
 */
@ExtendWith(MockitoExtension.class)
class CitaServicioTest {

    @Mock
    private CitaRepositorio citaRepositorio;

    @InjectMocks
    private CitaServicio citaServicio;

    private final LocalDateTime fechaFutura =
            LocalDateTime.now().plusDays(3).truncatedTo(ChronoUnit.MINUTES);

    @Test
    void registrarCitaConDatosValidosGuardaCitaProgramada() {
        when(citaRepositorio.existsByIdProfesionalAndFechaHoraAndEstadoIn(
                eq(1L), eq(fechaFutura), any())).thenReturn(false);
        when(citaRepositorio.save(any(Cita.class)))
                .thenAnswer(invocacion -> invocacion.getArgument(0));

        Cita resultado = citaServicio.registrar(
                new CitaSolicitud(1L, 1L, fechaFutura, "Control general", null));

        assertEquals(EstadoCita.PROGRAMADA, resultado.getEstado());
        assertEquals("Control general", resultado.getMotivoConsulta());
        verify(citaRepositorio).save(any(Cita.class));
    }

    @Test
    void registrarCitaConFechaPasadaLanzaReglaNegocio() {
        CitaSolicitud solicitud = new CitaSolicitud(
                1L, 1L, LocalDateTime.now().minusDays(1), "Control", null);

        assertThrows(ReglaNegocioException.class, () -> citaServicio.registrar(solicitud));
        verify(citaRepositorio, never()).save(any(Cita.class));
    }

    @Test
    void registrarCitaConHorarioOcupadoLanzaConflicto() {
        when(citaRepositorio.existsByIdProfesionalAndFechaHoraAndEstadoIn(
                eq(1L), eq(fechaFutura), any())).thenReturn(true);
        CitaSolicitud solicitud = new CitaSolicitud(2L, 1L, fechaFutura, "Control", null);

        assertThrows(ConflictoHorarioException.class, () -> citaServicio.registrar(solicitud));
        verify(citaRepositorio, never()).save(any(Cita.class));
    }

    @Test
    void obtenerCitaInexistenteLanzaRecursoNoEncontrado() {
        when(citaRepositorio.findById(99L)).thenReturn(Optional.empty());

        assertThrows(RecursoNoEncontradoException.class, () -> citaServicio.obtener(99L));
    }

    @Test
    void cancelarCitaProgramadaCambiaSuEstadoACancelada() {
        Cita cita = crearCita(EstadoCita.PROGRAMADA);
        when(citaRepositorio.findById(5L)).thenReturn(Optional.of(cita));
        when(citaRepositorio.save(any(Cita.class)))
                .thenAnswer(invocacion -> invocacion.getArgument(0));

        Cita resultado = citaServicio.cancelar(5L);

        assertEquals(EstadoCita.CANCELADA, resultado.getEstado());
    }

    @Test
    void cancelarCitaAtendidaLanzaReglaNegocio() {
        when(citaRepositorio.findById(5L)).thenReturn(Optional.of(crearCita(EstadoCita.ATENDIDA)));

        assertThrows(ReglaNegocioException.class, () -> citaServicio.cancelar(5L));
        verify(citaRepositorio, never()).save(any(Cita.class));
    }

    /** Construye una cita de prueba con el estado indicado. */
    private Cita crearCita(EstadoCita estado) {
        Cita cita = new Cita();
        cita.setIdCita(5L);
        cita.setIdPaciente(1L);
        cita.setIdProfesional(1L);
        cita.setFechaHora(fechaFutura);
        cita.setMotivoConsulta("Control");
        cita.setEstado(estado);
        return cita;
    }
}
